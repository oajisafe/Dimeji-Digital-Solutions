import { FaLinkedinIn, FaInstagram } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="w-full py-20 bg-white">
      <div className="flex flex-col items-center font-primary gap-10 pb-14">
        <h2 className="text-center text-5xl font-bold">
          Book a 30 minutes chat for free
        </h2>
        <p className="text-xl text-center">
          There is no commitment, pressure, or obligations
        </p>
        <p>Free 30 min chat</p>
      </div>
      <div className="md:w-[80%] w-[93%] m-auto flex items-center justify-between md:flex-row gap-6 flex-col">
        <h2 className=" text-3xl font-bold text-center">
          I don't make promises, I show results
        </h2>
        <div className="flex items-center gap-3">
          <FaLinkedinIn className="text-3xl text-black" />
          <FaInstagram className="text-3xl text-black" />
        </div>
      </div>
    </footer>
  );
};

export default Footer;
